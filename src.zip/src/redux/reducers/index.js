import { combineReducers } from 'redux';
import logoBreef from './logoBreef';

const reducer = combineReducers({
  logoBreef,
});

export default reducer;