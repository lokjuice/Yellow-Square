import YooKassa from "./YooKassa";

export { YooKassa };