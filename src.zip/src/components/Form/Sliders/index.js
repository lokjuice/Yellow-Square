import Sliders from "./Sliders";

export { Sliders };