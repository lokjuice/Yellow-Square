import LogoInfo from "./LogoInfo";

export { LogoInfo };